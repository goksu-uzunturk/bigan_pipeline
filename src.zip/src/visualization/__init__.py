# automatically adjust figures layout
from matplotlib import rcParams
rcParams.update({'figure.autolayout': True})
